import { Button, Grid, styled } from "@mui/material";

interface GridDigitButton2Props{
    digit: string;
    enterDigit: (digit:string) => void;
    xs?: number;
}

const StyledButton = styled(Button)<{}>((props) => ({
    backgroundColor: "#a5a5a5",
    color: "#fff",
    borderRadius: 100,
    // aspectRatio: 1,
    width: "100%",
    fontSize:"1.5em",
    height: "100%",
  }));

export const GridDigitButton2: React.FC<GridDigitButton2Props> = ({
    digit,
    enterDigit,
    xs = 3
}) => {
    return(
        <Grid item xs={xs}>
            <StyledButton onClick={()=> enterDigit(digit)}>
                {digit}
            </StyledButton>
        </Grid>
    )
}