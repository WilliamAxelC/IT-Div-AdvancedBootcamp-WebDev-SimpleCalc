import React, { useState } from 'react';
import {Container, Grid, Paper, styled, Button} from "@mui/material";
import {Routes, Route, useNavigate, Link} from 'react-router-dom';
import { GridOperationButton } from './GridOperationButton';
import { GridOperation2Button } from './GridOperationButton2';
import { GridDigitButton } from './GridDigitButton';
import { GridDigitButton2 } from './GridDigitButton2';
import {SupportPage} from './SupportPage'


const OutputContainer = styled('div')(({theme})=>({
  width:"100%",
  textAlign:"right",
  height:"2em",
  backgroundColor:"#585657",
  borderRadius: "0 15px 0 0",
  marginTop: 0,
  paddingTop: 0,
  color: "#FFFFFF",
  padding: theme.spacing(2),
  fontSize:"3em",
  overflow:"hidden",
  paddingBottom: "1rem",
}))

const HistoryContainer = styled('div')(({theme})=>({
  width: "100%",
  height: "6rem",
  maxheight: "6em",
  textAlign: "right",
  backgroundColor: "#585657",
  borderRadius: "15px 0 0 0",
  marginTop: 0,
  paddingTop: 0,
  color: "#FFFFFF",
  padding: theme.spacing(2),
  fontSize: "1em",
  overflowY: "auto",
  paddingBottom: "1rem",

  "& ul": {
    listStyle: "none",
    padding: 0,
    margin: 0,
  },

  "& li": {
    marginBottom: theme.spacing(1),
  },
}))

const EqualsButton = styled(Button)(({theme})=>({
  width:"100%",
  height:"1.8em",
  borderRadius: "100px",
  color: "#FFFFFF",
  padding: theme.spacing(2),
  backgroundColor: "rgba(251, 162, 1)",
  fontSize:"2em",
}))

const SupportButton = styled(Button)(({theme})=>({
  backgroundColor: "#836343",
  color: "#fff",
  borderRadius: 100,
  aspectRatio: 1,
  width: "fit-content",
  fontSize:"1.5em",
}))

const CalculatorBase = styled(Paper)(({theme})=>(
  {
    marginTop: theme.spacing(4),
    borderRadius:15,
    backgroundColor:"#000000"
  }
))

function App() {
  const [currentValue, setCurrentValue] = useState("0");
  const [operation, setOperation] = useState("");
  const [prevValue, setPrevValue] = useState("");
  const [overwrite, setOverwrite] = useState(true);
  const [history, setHistory] = useState<string[]>([]);
  const navigate = useNavigate();

  const navigateToSupportPage = () => {
    navigate('./SupportPage');
  }
  
  const calculate = () =>{
    if(!prevValue || !operation) return currentValue;
    if(operation === "/" && currentValue === "0") return "Err";
      const curr = parseFloat(currentValue);
      const prev = parseFloat(prevValue);

      let result;
      switch(operation){
        case "+":
          result = prev + curr;
          break;
        case "/":
          result = prev / curr;
          break;
        case "x":
          result = prev * curr;
          break;
        case "-":
          result = prev - curr;
          break;
      }

      return result;
  }

  const equals = () =>{
    const val = calculate();
    setCurrentValue(`${val}`);
    setPrevValue("");
    setOperation("");
    setOverwrite(true)
    addListItem();
  }

  const clear = () =>{
    setPrevValue("");
    setOperation("");
    setCurrentValue("0");
    setOverwrite(true);
    setHistory([]);
  }

  const addListItem = () => {
    const newIndex = history.length + 1;
    const newItem = String(calculate()); // Explicitly cast to string
    setHistory((prevHistory) => [...prevHistory, newItem]);
  };

  const del = () =>{
    setCurrentValue(currentValue.slice(0, -1))
    setOverwrite(true);
  }

  const selectOperation = (operation: string) => {
    // if(prevValue){
    //   const val = calculate()
    //   setCurrentValue(`${val}`);
    //   setPrevValue(`${val}`);
    // }else{
    setPrevValue(currentValue);
    // }
    setOperation(operation);
    setCurrentValue(operation);
    setOverwrite(true);
  }

  const setDigit = (digit: string) => {
    if(currentValue[0] === "0" && digit ==="0") return;
    if(overwrite){
      setCurrentValue(digit);
    }else{
      setCurrentValue(`${currentValue}${digit}`);
    }
    setOverwrite(false);
  }

  return (
    <Container maxWidth="xs">
      <CalculatorBase elevation={3}>
        <Grid container spacing={1}>
          <Grid item xs={3}>
            <HistoryContainer>
              <ul>
                {history.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            </HistoryContainer>
          </Grid>
          <Grid item xs={9}>
            <OutputContainer>{currentValue}</OutputContainer>
          </Grid>
          <Grid item container columnSpacing={1} xs={12}>
            <GridOperation2Button 
              operation={"C"} 
              selectOperation={clear} 
              selectedOperation={operation}
            />
            <GridOperation2Button 
              operation={"DEL"} 
              selectOperation={del} 
              selectedOperation={operation}
            />
            <Grid item xs={3}>
              <SupportButton onClick={navigateToSupportPage}>
                ?
              </SupportButton>
            </Grid>
            
            <GridOperationButton 
              operation={"/"} 
              selectOperation={selectOperation} 
              selectedOperation={operation}
            />
          </Grid>
          <Grid item container columnSpacing={1} xs={12}>
            <GridDigitButton digit='1' enterDigit={setDigit}/>
            <GridDigitButton digit='2' enterDigit={setDigit}/>
            <GridDigitButton digit='3' enterDigit={setDigit}/>
            <GridOperationButton 
              operation={"x"} 
              selectOperation={selectOperation} 
              selectedOperation={operation}
            />
          </Grid>
          <Grid item container columnSpacing={1} xs={12}>
            <GridDigitButton digit='4' enterDigit={setDigit}/>
            <GridDigitButton digit='5' enterDigit={setDigit}/>
            <GridDigitButton digit='6' enterDigit={setDigit}/>
            <GridOperationButton 
              operation={"-"} 
              selectOperation={selectOperation} 
              selectedOperation={operation}
            />
          </Grid>
          <Grid item container columnSpacing={1} xs={12}>
            <GridDigitButton digit='7' enterDigit={setDigit}/>
            <GridDigitButton digit='8' enterDigit={setDigit}/>
            <GridDigitButton digit='9' enterDigit={setDigit}/>
            <GridOperationButton 
              operation={"+"} 
              selectOperation={selectOperation} 
              selectedOperation={operation}
            />
          </Grid>
          <Grid item container columnSpacing={1} xs={12}>
            <GridDigitButton2 digit='0' enterDigit={setDigit} xs={6}/>
            <Grid item xs={6}>
              <EqualsButton onClick={equals}>
                =
              </EqualsButton>
            </Grid>
          </Grid>
        </Grid>
      </CalculatorBase>
      <Routes>
        <Route path="/" element={<CalculatorBase />} />
        <Route path="/SupportPage" element={<SupportPage />} />
      </Routes>
    </Container>
  );
}

export default App;