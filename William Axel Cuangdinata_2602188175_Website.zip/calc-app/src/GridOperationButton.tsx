import { Button, Grid, styled } from "@mui/material";

interface GridOperationButtonProps{
    operation: string;
    selectOperation: (operation:string) => void;
    selectedOperation: string;
}

const StyledButton = styled(Button)<{ selected: boolean }>((props) => ({
    backgroundColor: "rgba(251, 162, 1)",
    color: "#fff",
    borderColor: props.selected ? "#fffff" : "rgba(251, 162, 1, 0.5)",
    borderRadius: 100,
    aspectRatio: 1,
    width: "fit-content",
    fontSize:"1.5em",
  }));

export const GridOperationButton: React.FC<GridOperationButtonProps> = ({
    operation,
    selectedOperation,
    selectOperation,
}) => {
    return(
        <Grid item xs={3}>
            <StyledButton 
            fullWidth 
            variant="contained" 
            onClick={()=> selectOperation(operation)}
            selected={selectedOperation === operation}
            >
                {operation}
            </StyledButton>
        </Grid>
    );
};