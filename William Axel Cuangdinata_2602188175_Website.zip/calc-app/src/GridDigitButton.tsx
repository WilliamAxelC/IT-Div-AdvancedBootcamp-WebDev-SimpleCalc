import { Button, Grid, styled } from "@mui/material";

interface GridDigitButtonProps{
    digit: string;
    enterDigit: (digit:string) => void;
    xs?: number;
}

const StyledButton = styled(Button)<{}>((props) => ({
    backgroundColor: "#a5a5a5",
    color: "#fff",
    borderRadius: 100,
    aspectRatio: 1,
    width: "fit-content",
    fontSize:"1.5em",
  }));

export const GridDigitButton: React.FC<GridDigitButtonProps> = ({
    digit,
    enterDigit,
    xs = 3
}) => {
    return(
        <Grid item xs={xs}>
            <StyledButton onClick={()=> enterDigit(digit)}>
                {digit}
            </StyledButton>
        </Grid>
    )
}