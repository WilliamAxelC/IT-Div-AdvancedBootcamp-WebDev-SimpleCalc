import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import {SupportPage} from './SupportPage';
import theme from './theme';
import { ThemeProvider } from '@emotion/react';
import { CssBaseline } from '@mui/material';
import { BrowserRouter, Routes, Route, useNavigate, Link } from 'react-router-dom';

ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
      <ThemeProvider theme={theme}>
      <CssBaseline>
        <Routes>
          <Route path="/" element={<App />} />
          <Route path="/SupportPage" element={<SupportPage />} />
        </Routes>
      </CssBaseline>
      </ThemeProvider>
    </BrowserRouter>
  </React.StrictMode>,
  document.getElementById('root')
);
