//SupportPage.tsx
import React, { useState } from 'react';

interface ThankYouPopupProps {
    ticketNumber: number;
    onClose: () => void;
  }
  
  const ThankYouPopup: React.FC<{ ticketNumber: number | null; onClose: () => void }> = ({ ticketNumber, onClose }) => {
    return (
      <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center bg-gray-800 bg-opacity-50">
        <div className="bg-black p-8 rounded-md">
          <h2 className="text-2xl mb-4">Thank you for sending a report!</h2>
          <p>Your ticket number is: {ticketNumber}</p>
          <button className="mt-4 bg-orange-400 hover:bg-orange-500 text-white py-2 px-4 rounded-md" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    );
  };

export const SupportPage = () => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [ticketNumber, setTicketNumber] = useState<number | null>(null);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const randomTicketNumber = Math.floor(Math.random() * 10000) + 1;
    setTicketNumber(randomTicketNumber);
    setFormSubmitted(true);
  };

  const handleClosePopup = () => {
    setFormSubmitted(false);
    setTicketNumber(null);
  };
  
  return (

    <div className='p-10 flex align-middle justify-left flex-col max-w-5xl'>
        <a href="./" className='mb-5 p-1 text-white  bg-transparent border-white border-2 rounded-md hover:border-orange-500 hover:text-orange-400 outline-none w-fit'>
            Back to Calc</a>
        <div className='border-solid border-b-2 w-full mb-5'>
            <h1 className='text-4xl'>Support Ticket Form</h1>
        </div>
        {formSubmitted ? (
        <ThankYouPopup ticketNumber={ticketNumber} onClose={handleClosePopup} />
      ) : (
        <form action="" onSubmit={handleSubmit} className='flex flex-col max-w-5xl'>
            <div className='w-full flex flex-row max-w-5xl'>
                <div className='flex flex-col mr-5'>
                    <h2 className='text-xl mb-1'>Name*</h2>
                    <div className='flex flex-row mb-5'>
                        <div className='flex flex-col mr-5'>
                            <input type="fname" id='first-name-input' className='p-2 text-white bg-transparent border-white border-2 rounded-md focus:border-orange-500 outline-none' required />
                            <label htmlFor="first-name-input">First</label>
                        </div>
                        <div className='flex flex-col ml-5'>
                            <input type="lname" id='last-name-input' className='p-2 text-white  bg-transparent border-white border-2 rounded-md focus:border-orange-500 outline-none' required />
                            <label htmlFor="last-name-input">Last</label>
                        </div>
                    </div>
                    <label htmlFor="email-input" className='text-xl mb-1'>Email*</label>
                    <input type="email" id='email-input' className='p-2 text-white mb-5  bg-transparent border-white border-2 rounded-md focus:border-orange-500 outline-none' required />

                    <h2 className='text-xl mb-1'>Topic*</h2>
                    <h2 className='text-l'>How can we help you today?</h2>
                    <ul>
                        <li>
                            <input type="radio" id='topic-input-1' name='topic-input' className='text-black mr-2' required />
                            <label htmlFor="topic-input-1" className='text-m'>General</label>
                        </li>
                        <li>
                            <input type="radio" id='topic-input-2' name='topic-input' className='text-black mr-2' required />
                            <label htmlFor="topic-input-2" className='text-m'>Bug Report</label>
                        </li>
                    </ul>
                </div>
                <div className='flex flex-col ml-5 w-full'>
                    <label className='text-xl mb-1' htmlFor="description-input">Description</label>
                    <textarea name="description-input" id="description-input" className='p-2 text-white bg-transparent border-white border-2 rounded-md focus:border-orange-500 outline-none w-full h-full'></textarea>
                </div>
            </div>
            <div className='flex flex-row-reverse'>

            <input type="submit" value="SEND" className='w-1/4 h-10 mt-5 rounded-md bg-orange-400 hover:bg-orange-500' />
            </div>
        </form>
      )}
    </div>
  );
};

export default SupportPage;